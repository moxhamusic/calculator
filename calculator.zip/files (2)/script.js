// ---------------------------------------------------------
// Amber Calc — calculator logic
// ---------------------------------------------------------

const expressionEl = document.getElementById('expression');
const resultEl = document.getElementById('result');
const keys = document.querySelectorAll('.key');

// current expression as typed, e.g. "12+8"
let expression = '';
// true when the result box is showing an answer that should be
// replaced (not appended to) if the user types a new digit next
let justEvaluated = false;

const OPERATOR_MAP = {
  '÷': '/',
  '×': '*',
  '−': '-',
  '+': '+',
};

function render() {
  expressionEl.value = expression;
  resultEl.value = expression === '' ? '0' : expression;
}

function isOperator(char) {
  return ['+', '−', '×', '÷'].includes(char);
}

// --- Basic arithmetic operations ---------------------------------
function add(a, b) {
  return a + b;
}
function subtract(a, b) {
  return a - b;
}
function multiply(a, b) {
  return a * b;
}
function divide(a, b) {
  if (b === 0) return 'Error';
  return a / b;
}

// --- Square & cube -------------------------------------------------
function square(x) {
  return x * x;
}
function cube(x) {
  return x * x * x;
}

// --- Input handlers --------------------------------------------------
function appendNumber(digit) {
  if (justEvaluated) {
    expression = '';
    justEvaluated = false;
  }
  // prevent multiple leading zeros / multiple decimals in one number segment
  const lastNumber = expression.split(/[+\-×÷]/).pop();
  if (digit === '.' && lastNumber.includes('.')) return;
  expression += digit;
  render();
}

function chooseOperation(op) {
  if (expression === '' && op !== '−') return; // allow leading minus for negatives
  justEvaluated = false;

  const lastChar = expression.slice(-1);
  if (isOperator(lastChar)) {
    // replace the previous operator with the new one
    expression = expression.slice(0, -1) + op;
  } else {
    expression += op;
  }
  render();
}

function evaluateExpression() {
  if (expression === '') return;

  // Split into number/operator tokens, evaluated strictly left-to-right
  const tokens = expression.match(/(\d+\.?\d*)|[+\-×÷]/g);
  if (!tokens) return;

  let acc = parseFloat(tokens[0]);
  let i = 1;
  while (i < tokens.length - 1) {
    const op = OPERATOR_MAP[tokens[i]];
    const next = parseFloat(tokens[i + 1]);

    switch (op) {
      case '+':
        acc = add(acc, next);
        break;
      case '-':
        acc = subtract(acc, next);
        break;
      case '*':
        acc = multiply(acc, next);
        break;
      case '/':
        acc = divide(acc, next);
        if (acc === 'Error') {
          resultEl.value = 'Error: divide by 0';
          expression = '';
          justEvaluated = true;
          return;
        }
        break;
    }
    i += 2;
  }

  acc = Math.round(acc * 1e10) / 1e10; // trim floating point noise
  expression = String(acc);
  render();
  justEvaluated = true;
}

function applyPower(kind) {
  // Apply square/cube to whatever number is currently showing.
  // If an expression is mid-way through, evaluate it first.
  if (expression === '') return;
  evaluateExpression();

  const current = parseFloat(expression);
  if (Number.isNaN(current)) return;

  const value = kind === 'square' ? square(current) : cube(current);
  expression = String(Math.round(value * 1e10) / 1e10);
  render();
  justEvaluated = true;
}

function clearAll() {
  expression = '';
  justEvaluated = false;
  render();
}

function deleteLast() {
  if (justEvaluated) {
    clearAll();
    return;
  }
  expression = expression.slice(0, -1);
  render();
}

// --- Wire up buttons -------------------------------------------------
keys.forEach((key) => {
  key.addEventListener('click', () => {
    const { num, op, action } = key.dataset;

    if (num !== undefined) {
      appendNumber(num);
    } else if (op !== undefined) {
      chooseOperation(op);
    } else if (action === 'equals') {
      evaluateExpression();
    } else if (action === 'clear') {
      clearAll();
    } else if (action === 'delete') {
      deleteLast();
    } else if (action === 'square') {
      applyPower('square');
    } else if (action === 'cube') {
      applyPower('cube');
    }
  });
});

// --- Keyboard support --------------------------------------------------
window.addEventListener('keydown', (e) => {
  if (e.key >= '0' && e.key <= '9') {
    appendNumber(e.key);
  } else if (e.key === '.') {
    appendNumber('.');
  } else if (e.key === '+') {
    chooseOperation('+');
  } else if (e.key === '-') {
    chooseOperation('−');
  } else if (e.key === '*') {
    chooseOperation('×');
  } else if (e.key === '/') {
    e.preventDefault();
    chooseOperation('÷');
  } else if (e.key === 'Enter' || e.key === '=') {
    evaluateExpression();
  } else if (e.key === 'Backspace') {
    deleteLast();
  } else if (e.key === 'Escape') {
    clearAll();
  }
});

render();
