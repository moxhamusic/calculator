# Amber Calc — Calculator using Operators & Functions

A simple browser calculator that performs addition, subtraction,
multiplication, division, square (x²), and cube (x³).

## Project structure

```
calculator-project/
├── index.html        # Page structure — input/display + buttons
├── css/
│   └── style.css      # All styling (retro amber-LED calculator look)
├── js/
│   └── script.js       # All logic (arithmetic, square, cube, events)
└── README.md
```

The HTML links the CSS with a `<link>` tag in `<head>` and the JS with a
`<script>` tag before `</body>`, so all three files are connected.

## Features

- Digit buttons `0–9` and a decimal point
- Operator buttons: `+`, `−`, `×`, `÷`
- `x²` and `x³` buttons apply square/cube to the current value
- `C` clears everything, `DEL` removes the last character
- `=` evaluates the expression left-to-right
- Divide-by-zero is caught and shown as an error instead of crashing
- Full keyboard support (number keys, `+ - * /`, Enter, Backspace, Escape)

## Running it locally

No build step or server required — just open `index.html` in a browser.

